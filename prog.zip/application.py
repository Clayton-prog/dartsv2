from prog import application

if __name__ == "__main__":
    application.run()