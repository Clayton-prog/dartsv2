from flask import Flask

applicatoin = app = Flask(__name__)

from app import views